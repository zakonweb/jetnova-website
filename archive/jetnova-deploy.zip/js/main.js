/**
 * JetNova - World-Class AI Travel Platform
 * Premium JavaScript - Animations & Interactions
 * Version: 3.0
 */

(function() {
    'use strict';

    // ============================================================================
    // LOADING SCREEN
    // ============================================================================
    
    const loadingScreen = document.querySelector('.loading-screen');
    
    window.addEventListener('load', () => {
            setTimeout(() => {
            if (loadingScreen) {
                loadingScreen.classList.add('hidden');
            }
            // Trigger initial animations
            initAnimations();
        }, 500);
    });

    // ============================================================================
    // HEADER SCROLL EFFECT
    // ============================================================================
    
    const header = document.querySelector('.site-header');
    let lastScrollY = 0;
    
    function handleHeaderScroll() {
        const currentScrollY = window.scrollY;
        
        if (header) {
            if (currentScrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        }
        
        lastScrollY = currentScrollY;
    }
    
    window.addEventListener('scroll', handleHeaderScroll, { passive: true });

    // ============================================================================
    // SCROLL ANIMATIONS - Intersection Observer
    // ============================================================================
    
    function initAnimations() {
        const animatedElements = document.querySelectorAll('.animate-on-scroll');
        
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.1
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animated');
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);
        
        animatedElements.forEach(el => {
            observer.observe(el);
        });
    }

    // ============================================================================
    // COUNTER ANIMATION - Number Count Up
    // ============================================================================
    
    function animateCounter(element) {
        const target = parseInt(element.getAttribute('data-count'));
        const duration = 2000; // 2 seconds
        const start = 0;
        const startTime = performance.now();
        
        function updateCounter(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            // Easing function - ease out expo
            const easeOutExpo = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
            const current = Math.floor(start + (target - start) * easeOutExpo);
            
            element.textContent = current.toLocaleString();
            
            if (progress < 1) {
                requestAnimationFrame(updateCounter);
            } else {
                element.textContent = target.toLocaleString();
            }
        }
        
        requestAnimationFrame(updateCounter);
    }
    
    // Initialize counters when they come into view
    function initCounters() {
        const counters = document.querySelectorAll('[data-count]');
        
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.5
        };
        
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
                    animateCounter(entry.target);
            observer.unobserve(entry.target);
          }
        });
        }, observerOptions);
        
        counters.forEach(counter => {
            observer.observe(counter);
        });
    }
    
    document.addEventListener('DOMContentLoaded', initCounters);

    // ============================================================================
    // SMOOTH SCROLL FOR ANCHOR LINKS
    // ============================================================================
    
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                const headerHeight = header ? header.offsetHeight : 0;
                const targetPosition = targetElement.getBoundingClientRect().top + window.scrollY - headerHeight - 20;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // ============================================================================
    // BACK TO TOP BUTTON
    // ============================================================================
    
    const backToTop = document.querySelector('.back-to-top');
    
    function handleBackToTop() {
        if (backToTop) {
            if (window.scrollY > 500) {
                backToTop.classList.add('visible');
            } else {
                backToTop.classList.remove('visible');
            }
        }
    }
    
    window.addEventListener('scroll', handleBackToTop, { passive: true });
    
    if (backToTop) {
        backToTop.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // ============================================================================
    // FAQ ACCORDION
    // ============================================================================
    
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        if (question) {
            question.addEventListener('click', () => {
                const isActive = item.classList.contains('active');
                
                // Close all items
                faqItems.forEach(i => i.classList.remove('active'));
                
                // Open clicked item if it wasn't active
                if (!isActive) {
                    item.classList.add('active');
                }
      });
    }
  });
  
    // ============================================================================
    // DEMO WIDGET - Interactive Chat
    // ============================================================================
    
    const demoChat = document.getElementById('demoChat');
    const demoInput = document.getElementById('demoInput');
    const demoSend = document.getElementById('demoSend');
    const suggestionChips = document.querySelectorAll('.suggestion-chip');
    
    const demoResponses = {
        'flight': '✈️ I can help you find flights! Please tell me:\n\n• Where are you flying from?\n• Where are you going?\n• When do you want to travel?\n\nFor example: "Flights from NYC to London next Friday"',
        'track': '📍 To track a flight, I need the flight number.\n\nJust send me the airline code and flight number like:\n• BA 101\n• AA 123\n• UA 456\n\nI\'ll give you real-time status updates!',
        'hotel': '🏨 Looking for hotels? Great choice!\n\nTell me:\n• Which city?\n• Check-in and check-out dates?\n• Number of guests?\n\nI\'ll find you the best deals from our partner network.',
        'tokyo': '🗾 Tokyo is amazing! Best times to visit:\n\n🌸 Spring (Mar-May): Cherry blossoms\n☀️ Fall (Sep-Nov): Beautiful foliage\n❄️ Winter (Dec-Feb): Clear skies, Mt. Fuji views\n\nAvoid rainy season (June-July) and peak summer heat (Aug).',
        'default': '👋 I\'m your JetNova AI assistant! I can help with:\n\n✈️ Flight searches & bookings\n📍 Live flight tracking\n🏨 Hotel reservations\n🌍 Travel recommendations\n\nWhat would you like to do?'
    };
    
    function addMessage(text, isUser = false) {
        const message = document.createElement('div');
        message.className = `message ${isUser ? 'user' : 'bot'}`;
        message.style.opacity = '0';
        message.style.transform = 'translateY(10px)';
        message.innerHTML = text.replace(/\n/g, '<br>');
        
        if (demoChat) {
            demoChat.appendChild(message);
            demoChat.scrollTop = demoChat.scrollHeight;
            
            // Animate in
  setTimeout(() => {
                message.style.transition = 'all 0.3s ease';
                message.style.opacity = '1';
                message.style.transform = 'translateY(0)';
            }, 10);
        }
    }
    
    function getResponse(text) {
        const lowerText = text.toLowerCase();
        
        if (lowerText.includes('flight') || lowerText.includes('fly')) {
            return demoResponses.flight;
        } else if (lowerText.includes('track') || lowerText.match(/[A-Z]{2}\s*\d{3}/i)) {
            return demoResponses.track;
        } else if (lowerText.includes('hotel') || lowerText.includes('stay')) {
            return demoResponses.hotel;
        } else if (lowerText.includes('tokyo') || lowerText.includes('japan')) {
            return demoResponses.tokyo;
        } else {
            return demoResponses.default;
        }
    }
    
    function handleDemoInput() {
        const text = demoInput.value.trim();
        
        if (text) {
            addMessage(text, true);
            demoInput.value = '';
            
            // Simulate typing delay
            setTimeout(() => {
                addMessage(getResponse(text), false);
            }, 800);
        }
    }
    
    if (demoSend) {
        demoSend.addEventListener('click', handleDemoInput);
    }
    
    if (demoInput) {
        demoInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                handleDemoInput();
            }
        });
    }
    
    // Suggestion chips
    suggestionChips.forEach(chip => {
        chip.addEventListener('click', () => {
            if (demoInput) {
                demoInput.value = chip.textContent;
                handleDemoInput();
            }
        });
    });

    // ============================================================================
    // VIDEO PLACEHOLDER - Click to Play
    // ============================================================================
    
    const videoTrigger = document.getElementById('videoTrigger');
    
    if (videoTrigger) {
        videoTrigger.addEventListener('click', () => {
            // Replace with actual video embed or modal
            const videoUrl = 'https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1';
            
            const iframe = document.createElement('iframe');
            iframe.src = videoUrl;
            iframe.style.cssText = 'position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: none;';
            iframe.setAttribute('allowfullscreen', '');
            iframe.setAttribute('allow', 'autoplay; encrypted-media');
            
            videoTrigger.style.position = 'relative';
            videoTrigger.innerHTML = '';
            videoTrigger.appendChild(iframe);
        });
    }

    // ============================================================================
    // MOBILE MENU TOGGLE
    // ============================================================================
    
    const mobileToggle = document.querySelector('.mobile-menu-toggle');
  const mobileMenu = document.querySelector('.mobile-menu');
  
    if (mobileToggle) {
        mobileToggle.addEventListener('click', () => {
            mobileToggle.classList.toggle('active');
    if (mobileMenu) {
      mobileMenu.classList.toggle('active');
    }
            document.body.classList.toggle('menu-open');
        });
    }

    // ============================================================================
    // PARALLAX EFFECT - Subtle on Hero
    // ============================================================================
    
    function handleParallax() {
        const parallaxElements = document.querySelectorAll('[data-parallax]');
        const scrollY = window.scrollY;
        
        parallaxElements.forEach(el => {
            const speed = parseFloat(el.getAttribute('data-parallax')) || 0.5;
            const offset = scrollY * speed;
            el.style.transform = `translateY(${offset}px)`;
        });
    }
    
    // Only enable parallax on larger screens
    if (window.innerWidth > 768) {
        window.addEventListener('scroll', handleParallax, { passive: true });
    }

    // ============================================================================
    // INTERSECTION OBSERVER FOR STAGGERED ANIMATIONS
    // ============================================================================
    
    function initStaggeredAnimations() {
        const grids = document.querySelectorAll('.indicators-grid, .pricing-grid, .testimonials-grid, .steps-container');
        
        grids.forEach(grid => {
            const children = grid.children;
            
            const observer = new IntersectionObserver((entries) => {
                if (entries[0].isIntersecting) {
                    Array.from(children).forEach((child, index) => {
    setTimeout(() => {
                            child.style.opacity = '1';
                            child.style.transform = 'translateY(0)';
                        }, index * 150);
                    });
                    observer.unobserve(grid);
                }
            }, { threshold: 0.2 });
            
            // Set initial state
            Array.from(children).forEach(child => {
                child.style.opacity = '0';
                child.style.transform = 'translateY(30px)';
                child.style.transition = 'all 0.6s cubic-bezier(0.16, 1, 0.3, 1)';
            });
            
            observer.observe(grid);
        });
    }
    
    document.addEventListener('DOMContentLoaded', initStaggeredAnimations);

    // ============================================================================
    // TYPING ANIMATION FOR HERO SUBTITLE
    // ============================================================================
    
    function initTypingAnimation() {
        const typingElements = document.querySelectorAll('[data-typing]');
        
        typingElements.forEach(el => {
            const text = el.getAttribute('data-typing');
            const speed = parseInt(el.getAttribute('data-typing-speed')) || 50;
            
            el.textContent = '';
            
            let i = 0;
            function type() {
                if (i < text.length) {
                    el.textContent += text.charAt(i);
                    i++;
                    setTimeout(type, speed);
                }
            }
            
            // Start typing when element is in view
            const observer = new IntersectionObserver((entries) => {
                if (entries[0].isIntersecting) {
                    type();
                    observer.unobserve(el);
                }
            });
            
            observer.observe(el);
        });
    }

    // ============================================================================
    // CURSOR GLOW EFFECT - Premium Touch
    // ============================================================================
    
    function initCursorGlow() {
        const glowElements = document.querySelectorAll('.indicator-card, .pricing-card, .feature-visual');
        
        glowElements.forEach(el => {
            el.addEventListener('mousemove', (e) => {
                const rect = el.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                el.style.setProperty('--mouse-x', `${x}px`);
                el.style.setProperty('--mouse-y', `${y}px`);
            });
        });
    }
    
    document.addEventListener('DOMContentLoaded', initCursorGlow);

    // ============================================================================
    // KEYBOARD NAVIGATION
    // ============================================================================
    
    document.addEventListener('keydown', (e) => {
        // ESC to close mobile menu
        if (e.key === 'Escape') {
            if (mobileMenu && mobileMenu.classList.contains('active')) {
                mobileToggle.click();
            }
        }
    });

    // ============================================================================
    // PERFORMANCE - Request Animation Frame Throttle
    // ============================================================================
    
    let ticking = false;
    
    function requestTick(fn) {
        if (!ticking) {
            requestAnimationFrame(() => {
                fn();
                ticking = false;
            });
            ticking = true;
        }
    }

    // ============================================================================
    // PARTICLE BACKGROUND SYSTEM
    // ============================================================================
    
    function initParticles() {
        const canvas = document.createElement('canvas');
        canvas.id = 'particles-canvas';
        document.body.prepend(canvas);
        
        const ctx = canvas.getContext('2d');
        let particles = [];
        let animationId;
        
        function resize() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }
        
        resize();
        window.addEventListener('resize', resize);
        
        class Particle {
            constructor() {
                this.reset();
            }
            
            reset() {
                this.x = Math.random() * canvas.width;
                this.y = Math.random() * canvas.height;
                this.size = Math.random() * 2 + 0.5;
                this.speedX = (Math.random() - 0.5) * 0.5;
                this.speedY = (Math.random() - 0.5) * 0.5;
                this.opacity = Math.random() * 0.5 + 0.1;
                this.hue = Math.random() * 60 + 220; // Blue to purple range
            }
            
            update() {
                this.x += this.speedX;
                this.y += this.speedY;
                
                if (this.x < 0 || this.x > canvas.width || 
                    this.y < 0 || this.y > canvas.height) {
                    this.reset();
                }
            }
            
            draw() {
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                ctx.fillStyle = `hsla(${this.hue}, 70%, 60%, ${this.opacity})`;
                ctx.fill();
            }
        }
        
        // Create particles
        const particleCount = Math.min(80, Math.floor(window.innerWidth / 20));
        for (let i = 0; i < particleCount; i++) {
            particles.push(new Particle());
        }
        
        function animate() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            particles.forEach(particle => {
                particle.update();
                particle.draw();
            });
            
            // Draw connections
            particles.forEach((p1, i) => {
                particles.slice(i + 1).forEach(p2 => {
                    const dx = p1.x - p2.x;
                    const dy = p1.y - p2.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    
                    if (distance < 150) {
                        ctx.beginPath();
                        ctx.strokeStyle = `rgba(102, 126, 234, ${0.1 * (1 - distance / 150)})`;
                        ctx.lineWidth = 0.5;
                        ctx.moveTo(p1.x, p1.y);
                        ctx.lineTo(p2.x, p2.y);
                        ctx.stroke();
                    }
                });
            });
            
            animationId = requestAnimationFrame(animate);
        }
        
        animate();
        
        // Cleanup on page hide
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                cancelAnimationFrame(animationId);
            } else {
                animate();
            }
        });
    }
    
    // Only init particles on larger screens for performance
    if (window.innerWidth > 768 && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        document.addEventListener('DOMContentLoaded', initParticles);
    }

    // ============================================================================
    // ENHANCED MOBILE MENU
    // ============================================================================
    
    function initMobileMenu() {
        const toggle = document.querySelector('.mobile-menu-toggle');
        const menu = document.querySelector('.mobile-menu');
        const menuLinks = document.querySelectorAll('.mobile-nav a');
        
        if (!toggle || !menu) return;
        
        toggle.addEventListener('click', () => {
            toggle.classList.toggle('active');
            menu.classList.toggle('active');
            document.body.classList.toggle('menu-open');
        });
        
        // Close menu when clicking a link
        menuLinks.forEach(link => {
            link.addEventListener('click', () => {
                toggle.classList.remove('active');
                menu.classList.remove('active');
                document.body.classList.remove('menu-open');
            });
        });
        
        // Close on escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && menu.classList.contains('active')) {
                toggle.classList.remove('active');
                menu.classList.remove('active');
                document.body.classList.remove('menu-open');
            }
        });
    }
    
    document.addEventListener('DOMContentLoaded', initMobileMenu);

    // ============================================================================
    // MAGNETIC BUTTON EFFECT
    // ============================================================================
    
    function initMagneticButtons() {
        const buttons = document.querySelectorAll('.btn-primary, .cta-button');
        
        buttons.forEach(button => {
            button.addEventListener('mousemove', (e) => {
                const rect = button.getBoundingClientRect();
                const x = e.clientX - rect.left - rect.width / 2;
                const y = e.clientY - rect.top - rect.height / 2;
                
                button.style.transform = `translate(${x * 0.1}px, ${y * 0.1}px)`;
            });
            
            button.addEventListener('mouseleave', () => {
                button.style.transform = 'translate(0, 0)';
            });
        });
    }
    
    document.addEventListener('DOMContentLoaded', initMagneticButtons);

    // ============================================================================
    // SCROLL PROGRESS INDICATOR
    // ============================================================================
    
    function initScrollProgress() {
        const progressBar = document.createElement('div');
        progressBar.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            height: 3px;
            background: linear-gradient(90deg, #667eea, #764ba2);
            z-index: 10000;
            transition: width 0.1s ease;
            width: 0%;
        `;
        document.body.appendChild(progressBar);
        
        window.addEventListener('scroll', () => {
            const scrollTop = window.scrollY;
            const docHeight = document.documentElement.scrollHeight - window.innerHeight;
            const progress = (scrollTop / docHeight) * 100;
            progressBar.style.width = `${progress}%`;
        }, { passive: true });
    }
    
    document.addEventListener('DOMContentLoaded', initScrollProgress);

    // ============================================================================
    // TILT EFFECT ON CARDS
    // ============================================================================
    
    function initTiltEffect() {
        const cards = document.querySelectorAll('.indicator-card, .feature-visual, .pricing-card');
        
        cards.forEach(card => {
            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                const centerX = rect.width / 2;
                const centerY = rect.height / 2;
                const rotateX = (y - centerY) / 20;
                const rotateY = (centerX - x) / 20;
                
                card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(10px)`;
            });
            
            card.addEventListener('mouseleave', () => {
                card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateZ(0)';
            });
        });
    }
    
    // Only on desktop
    if (window.innerWidth > 1024) {
        document.addEventListener('DOMContentLoaded', initTiltEffect);
    }

    // ============================================================================
    // SMOOTH NUMBER INCREMENT
    // ============================================================================
    
    function initSmoothNumbers() {
        const numbers = document.querySelectorAll('.pricing-price');
        
        numbers.forEach(num => {
            const text = num.textContent;
            if (text.includes('$')) {
                num.addEventListener('mouseenter', () => {
                    num.style.transform = 'scale(1.1)';
                    num.style.transition = 'transform 0.3s ease';
                });
                num.addEventListener('mouseleave', () => {
                    num.style.transform = 'scale(1)';
                });
            }
        });
    }
    
    document.addEventListener('DOMContentLoaded', initSmoothNumbers);

    // ============================================================================
    // PRELOAD CRITICAL RESOURCES
    // ============================================================================
    
    function preloadResources() {
        // Preload fonts
        const fontPreload = document.createElement('link');
        fontPreload.rel = 'preload';
        fontPreload.as = 'style';
        fontPreload.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap';
        document.head.appendChild(fontPreload);
    }
    
    preloadResources();

    // ============================================================================
    // EASTER EGG - KONAMI CODE
    // ============================================================================
    
    const konamiCode = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'b', 'a'];
    let konamiIndex = 0;
    
    document.addEventListener('keydown', (e) => {
        if (e.key === konamiCode[konamiIndex]) {
            konamiIndex++;
            if (konamiIndex === konamiCode.length) {
                document.body.style.animation = 'rainbow 2s ease infinite';
                setTimeout(() => {
                    document.body.style.animation = '';
                }, 5000);
                konamiIndex = 0;
            }
        } else {
            konamiIndex = 0;
        }
    });

    // ============================================================================
    // INITIALIZE ON DOM READY
    // ============================================================================
    
    document.addEventListener('DOMContentLoaded', () => {
        // Add loaded class to body for CSS transitions
        document.body.classList.add('dom-loaded');
        
        // Console branding
        console.log('%c✈️ JetNova', 'font-size: 24px; font-weight: bold; color: #667eea;');
        console.log('%cAI-Powered Travel Platform', 'font-size: 14px; color: #764ba2;');
        console.log('%chttps://jetnova-ai.com', 'font-size: 12px; color: #888;');
    });

})();
